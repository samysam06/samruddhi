package com.example.myapplication;

import android.app.Activity;

public class SecondFragment extends Activity {
}
